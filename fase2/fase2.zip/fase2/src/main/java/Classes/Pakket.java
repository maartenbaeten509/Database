package Classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Pakket {

    @Column(name = "pakketnr")
    @Id
    @GeneratedValue
    private int pakketnr; // PK, AI

    @Column
    private String Naam;

    @Column
    private int aantalVolwassenen; //NN

    @Column
    private int aantalKinderen; //NN


    public Pakket(int pakketnr, String naam, int aantalVolwassenen, int aantalKinderen) {
        this.pakketnr = pakketnr;
        Naam = naam;
        this.aantalVolwassenen = aantalVolwassenen;
        this.aantalKinderen = aantalKinderen;
    }

    public Pakket(int pakketnr, int aantalVolwassenen, int aantalKinderen) {
        this.pakketnr = pakketnr;
        this.aantalVolwassenen = aantalVolwassenen;
        this.aantalKinderen = aantalKinderen;
    }

    public int getPakketnr() {
        return pakketnr;
    }

    public void setPakketnr(int pakketnr) {
        this.pakketnr = pakketnr;
    }

    public String getNaam() {
        return Naam;
    }

    public void setNaam(String naam) {
        Naam = naam;
    }

    public int getAantalVolwassenen() {
        return aantalVolwassenen;
    }

    public void setAantalVolwassenen(int aantalVolwassenen) {
        this.aantalVolwassenen = aantalVolwassenen;
    }

    public int getAantalKinderen() {
        return aantalKinderen;
    }

    public void setAantalKinderen(int aantalKinderen) {
        this.aantalKinderen = aantalKinderen;
    }
}
