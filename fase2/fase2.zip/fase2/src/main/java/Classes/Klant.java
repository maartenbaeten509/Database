package Classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Klant {

    @Column (name = "klantnr")
    @Id
    @GeneratedValue
    private int klantnr; // PK, NN, AI

    @Column (name = "artiestnr")
    private int anr; // FK

    @Column (name = "naam")
    private String naam;

    @Column (name = "straat")
    private String straat;

    @Column (name = "huisnr")
    private String huisnummer;

    @Column (name = "postcode")
    private int postcode;

    public Klant(int klantnr, int anr, String naam, String straat, String huisnummer, int postcode) {
        this.klantnr = klantnr;
        this.anr = anr;
        this.naam = naam;
        this.straat = straat;
        this.huisnummer = huisnummer;
        this.postcode = postcode;
    }
/*
    public Klant(int klantnr, String naam, String straat, String huisnummer, int postcode) {
        this.klantnr = klantnr;
        this.naam = naam;
        this.straat = straat;
        this.huisnummer = huisnummer;
        this.postcode = postcode;
    }

    public Klant(int klantnr, String naam, String straat, String huisnummer) {
        this.klantnr = klantnr;
        this.naam = naam;
        this.straat = straat;
        this.huisnummer = huisnummer;
    }

    public Klant(int klantnr, String naam, String straat) {
        this.klantnr = klantnr;
        this.naam = naam;
        this.straat = straat;
    }

    public Klant(int klantnr, String naam) {
        this.klantnr = klantnr;
        this.naam = naam;
    }

*/






    public int getKlantnr() {
        return klantnr;
    }

    public void setKlantnr(int klantnr) {
        this.klantnr = klantnr;
    }

    public int getAnr() {
        return anr;
    }

    public void setAnr(int anr) {
        this.anr = anr;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getStraat() {
        return straat;
    }

    public void setStraat(String straat) {
        this.straat = straat;
    }

    public String getHuisnummer() {
        return huisnummer;
    }

    public void setHuisnummer(String huisnummer) {
        this.huisnummer = huisnummer;
    }

    public int getPostcode() {
        return postcode;
    }

    public void setPostcode(int postcode) {
        this.postcode = postcode;
    }
}
