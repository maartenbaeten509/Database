package Classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Auteurs {
    @Column(name = "auternr")
    @Id
    @GeneratedValue
    private int anr; // PK, NN, AI

    @Column
    private String naam;


    public Auteurs(int anr, String naam) {
        this.anr = anr;
        this.naam = naam;
    }

    public Auteurs(int anr) {
        this.anr = anr;

    }


    public int getAnr() {
        return anr;
    }

    public void setAnr(int anr) {
        this.anr = anr;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }
}
