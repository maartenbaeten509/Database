package Classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Weeksamenstelling {

    @Column(name = "weeknr")
    @Id
    @GeneratedValue
    private int weeknr; // PK, NN

    @Column
    private int aanbodnr; // FK

    @Column
    private String productnaam; //FK

    public Weeksamenstelling(int weeknr, int aanbodnr, String productnaam) {
        this.weeknr = weeknr;
        this.aanbodnr = aanbodnr;
        this.productnaam = productnaam;
    }

    public int getWeeknr() {
        return weeknr;
    }

    public void setWeeknr(int weeknr) {
        this.weeknr = weeknr;
    }

    public int getAanbodnr() {
        return aanbodnr;
    }

    public void setAanbodnr(int aanbodnr) {
        this.aanbodnr = aanbodnr;
    }

    public String getProductnaam() {
        return productnaam;
    }

    public void setProductnaam(String productnaam) {
        this.productnaam = productnaam;
    }
}
