package Classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
    @Column(name = "prodcutNaam")
    @Id
    private String Naam; // PK, NN

    public Product(String naam) {
        Naam = naam;
    }

    public String getNaam() {
        return Naam;
    }

    public void setNaam(String naam) {
        Naam = naam;
    }
}
