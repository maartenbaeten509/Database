package Classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Levering {
    @Column(name = "leveringnr")
    @Id
    @GeneratedValue
    private int leveringnr; // PK, NN, AI

    @Column
    private int klantnr; // FK, NN

    @Column
    private int weeknr; // FK, NN

    @Column
    private int afgehaald; //NN

    @Column
    private int aanbodnr; // FK, NN

    public Levering(int leveringnr, int klantnr, int weeknr, int afgehaald, int aanbodnr) {
        this.leveringnr = leveringnr;
        this.klantnr = klantnr;
        this.weeknr = weeknr;
        this.afgehaald = afgehaald;
        this.aanbodnr = aanbodnr;
    }

    public int getLeveringnr() {
        return leveringnr;
    }

    public void setLeveringnr(int leveringnr) {
        this.leveringnr = leveringnr;
    }

    public int getKlantnr() {
        return klantnr;
    }

    public void setKlantnr(int klantnr) {
        this.klantnr = klantnr;
    }

    public int getWeeknr() {
        return weeknr;
    }

    public void setWeeknr(int weeknr) {
        this.weeknr = weeknr;
    }

    public int getAfgehaald() {
        return afgehaald;
    }

    public void setAfgehaald(int afgehaald) {
        this.afgehaald = afgehaald;
    }

    public int getAanbodnr() {
        return aanbodnr;
    }

    public void setAanbodnr(int aanbodnr) {
        this.aanbodnr = aanbodnr;
    }
}
