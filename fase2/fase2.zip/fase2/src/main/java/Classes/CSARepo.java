package Classes;

import java.util.List;

public interface CSARepo {

    List<Klant> getKlantById(int klantnr);
    void saveNewKlant(Klant klant);
    void updateKlant(Klant klant);

    List<Klant> getLeverancierById(int levnr);
    void saveNewLeverancier(Leverancier leverancier);
    void updateLeverancier(Leverancier leverancier);

}
