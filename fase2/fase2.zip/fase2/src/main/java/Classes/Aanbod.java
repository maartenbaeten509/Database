package Classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Aanbod {
    @Column(name = "aanbodnr")
    @Id
    @GeneratedValue
    private int aanbodnr; // PK, NN

    @Column
    private int levnr; // FK, NN

    @Column
    private int pakketnr; // FK, NN

    @Column
    private int prijs; // NN

    public Aanbod(int aanbodnr, int levnr, int pakketnr, int prijs) {
        this.aanbodnr = aanbodnr;
        this.levnr = levnr;
        this.pakketnr = pakketnr;
        this.prijs = prijs;
    }


    public int getAanbodnr() {
        return aanbodnr;
    }

    public void setAanbodnr(int aanbodnr) {
        this.aanbodnr = aanbodnr;
    }

    public int getLevnr() {
        return levnr;
    }

    public void setLevnr(int levnr) {
        this.levnr = levnr;
    }

    public int getPakketnr() {
        return pakketnr;
    }

    public void setPakketnr(int pakketnr) {
        this.pakketnr = pakketnr;
    }

    public int getPrijs() {
        return prijs;
    }

    public void setPrijs(int prijs) {
        this.prijs = prijs;
    }
}
