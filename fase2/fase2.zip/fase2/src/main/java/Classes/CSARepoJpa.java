package Classes;

import javax.persistence.EntityManager;
import javax.persistence.PrePersist;
import java.util.List;

public class CSARepoJpa implements CSARepo {

    private final EntityManager entityManager;

    public CSARepoJpa(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

//----------------------------------------------------------------------------
    @Override
    public List<Klant> getKlantById(int klantnr) {
        var criteriaBuilder = entityManager.getCriteriaBuilder();
        var query = criteriaBuilder.createQuery(Klant.class);
        var root = query.from(Klant.class);

        query.where(criteriaBuilder.equal(root.get("klantnr"), klantnr ));
        return entityManager.createQuery(query).getResultList();
    }
    @Override
    public void saveNewKlant(Klant klant) {
        entityManager.getTransaction().begin();
        entityManager.persist(klant);
        entityManager.getTransaction().commit();
    }
    @Override
    public void updateKlant(Klant klant) {
        entityManager.getTransaction().begin();
        entityManager.merge(klant);
        entityManager.getTransaction().commit();
    }
//------------------------------------------------------------------------
    @Override
    public List<Klant> getLeverancierById(int levnr) {
        var criteriaBuilder = entityManager.getCriteriaBuilder();
        var query = criteriaBuilder.createQuery(Klant.class);
        var root = query.from(Klant.class);

        query.where(criteriaBuilder.equal(root.get("levnr"), levnr ));
        return entityManager.createQuery(query).getResultList();
    }
    @Override
    public void saveNewLeverancier(Leverancier leverancier) {
        entityManager.getTransaction().begin();
        entityManager.persist(leverancier);
        entityManager.getTransaction().commit();
    }
    @Override
    public void updateLeverancier(Leverancier leverancier) {
        entityManager.getTransaction().begin();
        entityManager.merge(leverancier);
        entityManager.getTransaction().commit();
    }
//----------------------------------------------------------------------------

}
