

import Classes.CSARepo;
import Classes.CSARepoJpa;
import Classes.Klant;
import org.hibernate.engine.spi.IdentifierValue;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.tuple.IdentifierProperty;

import javax.persistence.Persistence;
import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;

public class main {

    public static void main(String[] args) {
        System.out.println("Bootstrapping JPA/Hibernate...");
        var sessionFactory = Persistence.createEntityManagerFactory("Classes");
        var entityManager = sessionFactory.createEntityManager();
        System.out.println("Bootstrapping JPA/Hibernate done");

        System.out.println("Bootstrapping Repository...");
        var repo = new CSARepoJpa(entityManager);
        System.out.println("Bootstrapping done");

        isMaartenEr(repo);

        Klant maarten = new Klant( 1, 1 , "maarten",  "mettekovenstraat",  "12",  3870);
        repo.saveNewKlant(maarten);

        isMaartenEr(repo);
    }

    private static void isMaartenEr(CSARepoJpa repo) {
        System.out.println("Is Jos er?");
        for(var eenKlant : repo.getKlantById(1)) {
            System.out.println(eenKlant);
        }
    }



}
